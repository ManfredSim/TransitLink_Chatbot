﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace TransitLinkChatbot.Dialogs
{
    public class MainDialog : ComponentDialog
    {
        private readonly IStatePropertyAccessor<Travel> _MainAccessor;

        public MainDialog(UserState userState)
            : base(nameof(MainDialog))
        {
            _MainAccessor = userState.CreateProperty<Travel>("Travel");


            // This array defines how the Waterfall will execute.
            var waterfallSteps = new WaterfallStep[]
            {
                ChooseDialogStepAsync,
                ToLocationStepAsync,
                FromLocationStepAsync,
                TransportStepAsync,
                SummaryStepAsync,
            };

            // Add named dialogs to the DialogSet. These names are saved in the dialog state.
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private static async Task<DialogTurnResult> ChooseDialogStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (stepContext.Context.Activity.Text == "I'm looking for directions.")
            {
                return await stepContext.NextAsync(null, cancellationToken);
            }
            else
            {
                return await stepContext.PromptAsync(nameof(ChoicePrompt),
                    new PromptOptions
                    {
                        Prompt = MessageFactory.Text("What would you like us to help you with?"),
                        Choices = ChoiceFactory.ToChoices(new List<string> { "I'm looking for directions." }),
                    }, cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> ToLocationStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (stepContext.Context.Activity.Text == "I'm looking for directions.")
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Where would you like to go to?") }, cancellationToken);
            }
            else
            {
                var msg = $"Thank you for your time!";
                await stepContext.Context.SendActivityAsync(MessageFactory.Text(msg), cancellationToken);
                return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> FromLocationStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["to_location"] = (string)stepContext.Result;
            if (stepContext.Values["to_location"] != null)
            {
                return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Where are you currently located at?") }, cancellationToken);
            }
            else
            {
                return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
            }
        }

        private static async Task<DialogTurnResult> TransportStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // WaterfallStep always finishes with the end of the Waterfall or with another dialog; here it is a Prompt Dialog.
            // Running a prompt here means the next WaterfallStep will be run when the user's response is received.
            stepContext.Values["from_location"] = (string)stepContext.Result;
            return await stepContext.PromptAsync(nameof(ChoicePrompt),
                new PromptOptions
                {
                    Prompt = MessageFactory.Text("How would you like to go to your destination?"),
                    Choices = ChoiceFactory.ToChoices(new List<string> { "Car", "Bus", "MRT", "Walk" }),
                }, cancellationToken);
        }

        private async Task<DialogTurnResult> SummaryStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["transport"] = ((FoundChoice)stepContext.Result).Value;
            var travel = await _MainAccessor.GetAsync(stepContext.Context, () => new Travel(), cancellationToken);

            travel.Transport = (string)stepContext.Values["transport"];
            travel.ToLocation = (string)stepContext.Values["to_location"];
            travel.FromLocation = (string)stepContext.Values["from_location"];

            var msg = $"It takes approximately 10 minutes to go from {travel.FromLocation} to {travel.ToLocation} via {travel.Transport}.";

            await stepContext.Context.SendActivityAsync(MessageFactory.Text(msg), cancellationToken);
            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
        }
    }
}
