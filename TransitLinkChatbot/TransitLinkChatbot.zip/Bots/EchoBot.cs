// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.6.2

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using System.Text;
using System.Net.Http;
using Microsoft.Bot.Builder.Dialogs;
using TransitLinkChatbot.Dialogs;
using Microsoft.Extensions.Logging;
using Microsoft.Recognizers.Text;

namespace TransitLinkChatbot.Bots
{
    public class EchoBot<T> : ActivityHandler where T : Dialog
    {
        protected readonly Dialog Dialog;
        protected readonly BotState ConversationState;
        protected readonly BotState UserState;
        class FollowUpCheckResult
        {
            [JsonProperty("answers")]
            public FollowUpCheckQnAAnswer[] Answers
            {
                get;
                set;
            }
        }

        class FollowUpCheckQnAAnswer
        {
            [JsonProperty("context")]
            public FollowUpCheckContext Context
            {
                get;
                set;
            }
        }

        class FollowUpCheckContext
        {
            [JsonProperty("prompts")]
            public FollowUpCheckPrompt[] Prompts
            {
                get;
                set;
            }
        }

        class FollowUpCheckPrompt
        {
            [JsonProperty("displayText")]
            public string DisplayText
            {
                get;
                set;
            }
        }
        public QnAMaker EchoBotQnA { get; private set; }

        public bool isRunning;
        
        public EchoBot(QnAMakerEndpoint endpoint, ConversationState conversationState, UserState userState, T dialog)
        {
            // connects to QnA Maker endpoint for each turn
            EchoBotQnA = new QnAMaker(endpoint);
            ConversationState = conversationState;
            UserState = userState;
            Dialog = dialog;
        }
        public override async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            await base.OnTurnAsync(turnContext, cancellationToken);

            // Save any state changes that might have occurred during the turn.
            await ConversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            await UserState.SaveChangesAsync(turnContext, false, cancellationToken);
        }

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            var qnaOptions = new QnAMakerOptions();
            qnaOptions.ScoreThreshold = 0.8F;
            // Pass the response entered by the user through the QnA service
            var results = await EchoBotQnA.GetAnswersAsync(turnContext, qnaOptions);
            if (results != null && results.Length > 0 && isRunning != true)
            {
                // create http client to perform qna query
                var followUpCheckHttpClient = new HttpClient();

                // add QnAAuthKey to Authorization header
                followUpCheckHttpClient.DefaultRequestHeaders.Add("Authorization", "6bdd6777-b320-4e47-90ff-3a59752cf7e4");

                // construct the qna query url
                var url = $"https://qa-service-183656l.azurewebsites.net/qnamaker/knowledgebases/7c8dfc23-28d6-42d0-a149-1036a9526f3b/generateAnswer";

                // post query
                var checkFollowUpJsonResponse = await followUpCheckHttpClient.PostAsync(url, new StringContent("{\"question\":\"" + turnContext.Activity.Text + "\"}", Encoding.UTF8, "application/json")).Result.Content.ReadAsStringAsync();

                // parse result
                var followUpCheckResult = JsonConvert.DeserializeObject<FollowUpCheckResult>(checkFollowUpJsonResponse);

                // initialize reply message containing the default answer
                var reply = MessageFactory.Text(results[0].Answer);

                if (followUpCheckResult.Answers.Length > 0 && followUpCheckResult.Answers[0].Context.Prompts.Length > 0)
                {
                    // if follow-up check contains valid answer and at least one prompt, add prompt text to SuggestedActions using CardAction one by one
                    reply.SuggestedActions = new SuggestedActions();
                    reply.SuggestedActions.Actions = new List<CardAction>();
                    for (int i = 0; i < followUpCheckResult.Answers[0].Context.Prompts.Length; i++)
                    {
                        var promptText = followUpCheckResult.Answers[0].Context.Prompts[i].DisplayText;
                        reply.SuggestedActions.Actions.Add(new CardAction() { Title = promptText, Type = ActionTypes.ImBack, Value = promptText });
                    }
                }
                isRunning = false;
                await turnContext.SendActivityAsync(reply, cancellationToken);
            }
            else
            {
                //Run the Dialog with the new message Activity.
                await Dialog.RunAsync(turnContext, ConversationState.CreateProperty<DialogState>(nameof(DialogState)), cancellationToken);
                isRunning = true;
                //// The QnA service did not have any results
                //// Proceed with the previous code
                //string strOutgoingText = $"Sorry, I don't understand what you mean by: '{turnContext.Activity.Text}'. Please try again.";
                //await turnContext.SendActivityAsync(MessageFactory.Text(strOutgoingText), cancellationToken);
            }
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            await SendIntroCardAsync(turnContext, cancellationToken);
            var welcomeText = "How can I be of your service today?";
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text(welcomeText, welcomeText), cancellationToken);
                }
            }
        }

        private static async Task SendIntroCardAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            var card = new HeroCard();
            card.Title = "Welcome to the TransitLink Chatbot!";
            card.Text = @"You may ask me about EZ-Link cards, concession cards, bus fares, our e-services and more! Please ask me anything and I will try my best to provide an answer.";
            card.Images = new List<CardImage>() { new CardImage("https://mir-s3-cdn-cf.behance.net/project_modules/disp/2cc65516711978.5603adb74ee58.jpg") };
            card.Buttons = new List<CardAction>()
            {
                new CardAction(ActionTypes.OpenUrl, "Visit our website", "https://lh3.googleusercontent.com/proxy/04gSylUaUrUjFLGcLu1DcDEnvIP_6P98DBtTe1d9SwYCSeYzv8aEFaZz9Xs_bS7dYuq6eJfar6Hd-Knyvc5oG0DILKsrJm4RwrN35_j9_GgPxROeixzMGZ7gklcdM-OSSrzT2GPVXMBBdCDWDjFLlWo", "Visit our website", "Visit our website", "https://www.transitlink.com.sg/"),
                new CardAction(ActionTypes.ImBack, title: "How do I top up my EZ-Link card?", value: "How do I top up my EZ-Link card?"),
                new CardAction(ActionTypes.ImBack, title: "How do I fix my EZ-Link card?", value: "How do I fix my EZ-Link card?"),
                new CardAction(ActionTypes.ImBack, title: "I'm looking for directions.", value: "I'm looking for directions."),
            };

            var response = MessageFactory.Attachment(card.ToAttachment());
            await turnContext.SendActivityAsync(response, cancellationToken);
        }
    }
}
