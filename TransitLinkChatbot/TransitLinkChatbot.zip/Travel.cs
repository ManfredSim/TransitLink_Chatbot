﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TransitLinkChatbot
{
    public class Travel
    {
        public string Transport { get; set; }
        public string ToLocation { get; set; }
        public string FromLocation { get; set; }
    }
}
